-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 23 nov. 2021 à 02:06
-- Version du serveur :  8.0.21
-- Version de PHP : 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `alarm`
--

-- --------------------------------------------------------

--
-- Structure de la table `alarm_one`
--

CREATE TABLE `alarm_one` (
  `id` int NOT NULL,
  `status` int NOT NULL,
  `z1` int NOT NULL,
  `z2` int NOT NULL,
  `z3` int NOT NULL,
  `z4` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `alarm_one`
--

INSERT INTO `alarm_one` (`id`, `status`, `z1`, `z2`, `z3`, `z4`) VALUES
(1, 1, 0, 0, 0, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `alarm_one`
--
ALTER TABLE `alarm_one`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
